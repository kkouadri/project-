import tkinter as tk
def open_second_window():
    second_window = tk.Toplevel(root)
    second_window.title("Second Window")
    label =tk.Label(second_window, text="This is the second window.")
    label.pack()
    root = tk.Tk()
    root.title("Main Window")
    label = tk.Label(root, text="This is the main window.")
    label.pack()
    button = tk.Button(root, text="Open Second Window", command=open_second_window)
    button.pack()
    root.mainloop()
